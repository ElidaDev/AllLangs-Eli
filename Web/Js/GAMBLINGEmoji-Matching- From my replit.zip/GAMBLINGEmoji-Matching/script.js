// create Phaser.Game object assigned to global variable named game
var game = new Phaser.Game(800, 600, Phaser.AUTO, 'my-game', { preload: preload, create: create, update: update });

// declare other global variables (for sprites, etc.)
var hello1;
var hello2;
var hello3;
var spacebar;
var scoreText;
var matchTXT;
var score = 0;

// preload game assets - runs one time when webpage first loads
function preload() {
  //gamevariable.load.typeofasset('nameOfAsset','FileName.extension',h,w)
  game.load.spritesheet('gamble', 'assets/gambling-sprite.png', 60, 60);
  game.load.audio('spin', 'assets/spinner.mp3')
  game.load.audio('2sound', 'assets/coin.wav')
  game.load.audio('3sound', 'assets/power-up.wav')
}

// create game world - runs one time after preload finishes
function create() {
  game.stage.backgroundColor = '#F0F0F0';

  //Load sprites
  gamble1 = game.add.sprite(game.world.centerX, game.world.centerY, 'gamble');
  gamble1.anchor.setTo(1, 0.5);
  gamble2 = game.add.sprite(game.world.centerX, game.world.centerY, 'gamble');
  gamble2.anchor.setTo(0, 0.5);
  gamble3 = game.add.sprite(game.world.centerX, game.world.centerY, 'gamble');
  gamble3.anchor.setTo(-1, 0.5);

  // Keybindings
  spacebar = game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

  //Audio section
  // obj = gameobj's add audio(audio asset, volume/1)
  spinSound = game.add.audio('spin', 0.3);
  spinSound.loop = true;
  match2sound = game.add.audio('2sound', 0.5);
  match3sound = game.add.audio('3sound', 0.5);

  //Text

  matchTXT = game.add.text(game.world.centerX - 25, game.world.centerY + 80, '',
    { font: 'Arial', fontSize: "20px", fontStyle: "bold", fill: "#FFCC00" });
  matchTXT.setShadow(1, 1, "#000", 2)
  scoreTXT = game.add.text(game.world.centerX, game.world.centerY - 80, 'Use SpaceBar to spin!',
    { font: 'Arial', fontSize: "20px", fontStyle: "bold", fill: "#FFCC00" });
  scoreTXT.setShadow(1, 1, "#000", 2)
}

// update game - runs repeatedly in loop after create finishes
function update() {
  if (spacebar.justDown) {
    spinSound.play();
  }
  else if (spacebar.isDown) {
    gamble1.frame = Math.floor(Math.random() * 2);
    gamble2.frame = Math.floor(Math.random() * 3);
    gamble3.frame = Math.floor(Math.random() * 2);
  }
  else if (spacebar.justUp) {
    spinSound.stop();
    checkForMatch();
  }
}

// add custom functions (for collisions, etc.) - only run when called
function checkForMatch() {
  if (gamble1.frame == gamble2.frame && gamble2.frame == gamble3.frame) {
    match3sound.play();
    matchTXT.text = "Good Job! You matched all 3! +100";
    matchTXT.fill = "#0F0";
    score += 100
  }
  else if (gamble1.frame == gamble2.frame || gamble1.frame == gamble3.frame || gamble2.frame == gamble3.frame) {
    match2sound.play();
    matchTXT.text = "Good Job! You matched 2/3! +25";
    matchTXT.fill = "#FF0";
    score += 25
  }
  else {
    matchTXT.text = "Try again! -10"
    matchTXT.fill = "#F00";
    score -= 10
  }
  console.log(score);
  scoreTXT.text = score;
}